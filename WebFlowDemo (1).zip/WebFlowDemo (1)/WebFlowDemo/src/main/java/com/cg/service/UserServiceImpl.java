/**
 * 
 */
package com.cg.service;

import org.springframework.stereotype.Service;

import com.cg.entity.User;

/**
 * @author Aditya Sinha
 *
 */
@Service
public class UserServiceImpl implements UserService {

	public User display(User user) {
		
		return user;
	}

	
}

